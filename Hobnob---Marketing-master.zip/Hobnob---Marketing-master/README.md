# Hobnob---Marketing
This is a solution given for a company to handle users interested in promoting their campaign using different social media platforms.

## Contributors
Contributors who have actively contributed to the success of the project

* **Aman Srivastava** - [Profile](https://github.com/aman11srivastava)
* **Aatir Qureshi** - [Profile](https://github.com/Aatir1224)
* **Janus Jerom** - [Profile](https://github.com/janusjerom)

## License
This project is licensed under the GNU Affero General Public License v3.0 license - see the [LICENSE](LICENSE) file for details.
